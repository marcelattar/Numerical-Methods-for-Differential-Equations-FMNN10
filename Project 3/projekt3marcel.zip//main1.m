N = 30;
M = 186;
tend = 0.1;

diffSolver(tend, N, M)
