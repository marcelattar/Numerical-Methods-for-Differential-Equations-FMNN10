%% Task 2.1a
clear all

i=1;
for l=2:10
    N = 2^l;
    dx = 1/(N+1);
    [eigenmatrix,lambdaApprox] = SturmSolver(N);
    
    for k=1:3
        lambdatrue = -(k*pi)^2;
        errormatrix(k,i) = lambdaApprox(k)-lambdatrue;
    end
    
    Nvec(i) = N;
    i = i+1;
end
    
loglog(Nvec, errormatrix)
grid on
set(gca,'FontSize',15)
xlabel('N');
ylabel('Error');

%% Task 2.1b 
clear all
format long
N = 499;
[eigenmatrix,lambdaApprox] = SturmSolver(N);

for k = 1:3
    vec(k) = lambdaApprox(k);
end

vec
%% Task 2.1c
clear all
N = 499;
dx = 1/(N+1);
[eigenmatrix,lambdaApprox] = SturmSolver(N);
x=0:dx:1;

hold on
grid on
for k=0:2
    eigenvector = eigenmatrix(:,end-k)'; % Takes out the eigenmodevector
    eigenvector = [0, eigenvector, 0];   % Appends the Boundary values
    plot(x,eigenvector)                  % Plot for the three first eigenmodes
end
%% Task 2.2

clear all
N = 499;
[eigenv, EV] = sturmsolver(N);
A = [];
dx = 1/(N+1);
xvec = 0:dx:1;
xvec(1) = [];
xvec(end) = [];

for k = 1:3  
    
   plot(xvec, eigenv(:,end+1-k))
   grid on
   hold on
end

