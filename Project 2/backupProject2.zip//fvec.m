function f = fvec(L,N)
f=[];

for n=0:L/(N+1):L;
   f =[f;sin(n)]; 
end
f(1) = [] ; % remove the first and last value.
f(end) = []; 
end